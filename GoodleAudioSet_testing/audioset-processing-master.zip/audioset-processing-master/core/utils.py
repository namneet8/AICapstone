# core/utils.py - Fixed version with better debugging
import csv
import os
import subprocess
import shlex
from shutil import copyfile
import time

# defaults
DEFAULT_LABEL_FILE = './data/class_labels_indices.csv'
DEFAULT_CSV_DATASET = './data/unbalanced_train_segments.csv'
DEFAULT_DEST_DIR = './output/'
DEFAULT_FS = 16000


def find(class_name, args):
    print("Finding examples for class " + class_name + " in: " + args.audio_data_dir)

    # construct path to destination dir
    dst_dir = args.destination_dir if args.destination_dir is not None else DEFAULT_DEST_DIR
    dst_dir_path = os.path.join(dst_dir, class_name)  # Create directory to store found files

    csv_dataset = args.csv_dataset if args.csv_dataset is not None else DEFAULT_CSV_DATASET

    class_id = get_label_id(class_name, args)  # Get ID corresponding to class_name
    youtube_ids = get_yt_ids(class_id, csv_dataset)  # Find all YouTube IDs which have class_id as a label
    find_files(youtube_ids, args.audio_data_dir, dst_dir_path)  # Find all files in audio_data_dir which are in the list of YouTube IDs


def download(class_name, args):
    print(f"\n=== Starting download process for class: {class_name} ===")
    
    new_csv = create_csv(class_name, args)
    if not new_csv or not os.path.exists(new_csv):
        print(f"ERROR: Could not create or find CSV file for {class_name}")
        return
    
    # construct path to destination dir
    dst_dir_root = args.destination_dir if args.destination_dir is not None else DEFAULT_DEST_DIR
    dst_dir = os.path.join(dst_dir_root, class_name)

    print(f"Destination directory: {dst_dir}")

    if not os.path.isdir(dst_dir):
        os.makedirs(dst_dir)
        print(f"Created directory: {dst_dir}")

    # Create failed downloads log
    failed_log = os.path.join(dst_dir_root, f"failed_{class_name.replace(' ', '_')}.txt")

    # Check existing files to skip
    existing_files = set()
    if os.path.exists(dst_dir):
        existing_files = {f for f in os.listdir(dst_dir) if f.endswith('.wav')}
        print(f"Found {len(existing_files)} existing WAV files, will skip these")

    # Load previously failed downloads to skip
    failed_files = set()
    if os.path.exists(failed_log):
        with open(failed_log, 'r') as f:
            failed_files = {line.strip() for line in f if line.strip()}
        print(f"Found {len(failed_files)} previously failed downloads, will skip these")

    # Check how many rows are in the CSV
    with open(new_csv) as dataset:
        reader = csv.reader(dataset)
        rows = list(reader)
        print(f"Found {len(rows)} rows in CSV for {class_name}")
        
        if len(rows) == 0:
            print(f"No data found for class {class_name}")
            return
    
    # Process each row
    success_count = 0
    fail_count = 0
    skip_count = 0
    
    try:
        for i, row in enumerate(rows):
            print(f"\n--- Processing {i+1}/{len(rows)} ---")
            
            if len(row) < 2:
                print(f"Skipping invalid row: {row}")
                continue
                
            youtube_id = str(row[0]).strip()
            start_time = str(row[1]).strip()
            
            # Create expected filename
            expected_filename = f"{youtube_id}_{start_time}.wav"
            output_file = os.path.join(dst_dir, expected_filename)
            
            print(f"YouTube ID: {youtube_id}, Start time: {start_time}s")
            print(f"Expected file: {expected_filename}")
            
            # Skip if already processed
            if expected_filename in existing_files:
                if os.path.exists(output_file) and os.path.getsize(output_file) > 1000:
                    print(f"✓ File already exists and looks valid: {expected_filename}")
                    skip_count += 1
                    continue
            
            if youtube_id in failed_files:
                print(f"⚠ Previously failed, skipping: {youtube_id}")
                skip_count += 1
                continue
            
            # Try to download
            success = False
            try:
                success = download_single_audio(youtube_id, start_time, output_file, args)
            except KeyboardInterrupt:
                print(f"\n\n⚠ Download interrupted by user")
                break
            except Exception as e:
                print(f"Unexpected error downloading {youtube_id}: {e}")
                success = False
            
            if success:
                success_count += 1
                print(f"✓ Successfully downloaded: {youtube_id}")
                existing_files.add(expected_filename)
                
                # Remove from failed list if it was there
                if youtube_id in failed_files:
                    failed_files.discard(youtube_id)
                    update_failed_log(failed_log, failed_files)
            else:
                fail_count += 1
                print(f"✗ Failed to download: {youtube_id}")
                
                # Add to failed list
                failed_files.add(youtube_id)
                append_to_failed_log(failed_log, youtube_id)
            
            # Add delay based on success rate
            if i < len(rows) - 1:
                if success:
                    time.sleep(2)  # Short delay for successful downloads
                else:
                    time.sleep(5)  # Longer delay after failures
    
    except KeyboardInterrupt:
        print(f"\n\n=== Download Interrupted ===")
        
    print(f"\n=== Download Summary for {class_name} ===")
    print(f"Successful: {success_count}")
    print(f"Failed: {fail_count}")
    print(f"Skipped (already exists): {skip_count}")
    print(f"Total processed: {success_count + fail_count + skip_count}")
    
    if fail_count > 0:
        print(f"\nFailed downloads logged to: {failed_log}")
        print("You can resume by running the same command again - failed files will be skipped")


def append_to_failed_log(log_file, youtube_id):
    """Add a failed download to the log"""
    try:
        with open(log_file, 'a') as f:
            f.write(f"{youtube_id}\n")
    except Exception as e:
        print(f"Warning: Could not write to failed log: {e}")


def update_failed_log(log_file, failed_set):
    """Update the entire failed log"""
    try:
        with open(log_file, 'w') as f:
            for youtube_id in failed_set:
                f.write(f"{youtube_id}\n")
    except Exception as e:
        print(f"Warning: Could not update failed log: {e}")


def download_single_audio(youtube_id, start_time, output_file, args):
    """
    Download a single audio clip with improved error handling and timeouts
    """
    print(f"Attempting to download: {youtube_id} from {start_time}s")
    
    # Clean up any partial downloads first
    cleanup_temp_files(output_file)
    
    # Quick check for common failure patterns to skip early
    if is_likely_unavailable(youtube_id):
        print(f"Skipping likely unavailable video: {youtube_id}")
        return False
    
    try:
        # Method 1: Try with cookies (shorter timeout)
        if os.path.exists("cookies.txt"):
            if download_with_cookies(youtube_id, start_time, output_file, args):
                return True
        
        # Method 2: Try basic download (very short timeout)
        if download_basic(youtube_id, start_time, output_file, args):
            return True
        
        # Method 3: Try full download (longer timeout but still reasonable)
        if download_full_then_extract(youtube_id, start_time, output_file, args):
            return True
        
        return False
        
    except Exception as e:
        print(f"Error in download methods for {youtube_id}: {e}")
        return False


def cleanup_temp_files(output_file):
    """Clean up temporary and partial files"""
    temp_patterns = [
        output_file + ".part",
        output_file + ".tmp", 
        output_file + ".temp",
        output_file.replace(".wav", ".webm"),
        output_file.replace(".wav", ".m4a"),
        output_file.replace(".wav", ".mp4")
    ]
    
    for temp_file in temp_patterns:
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except:
                pass


def is_likely_unavailable(youtube_id):
    """
    Quick heuristics to identify likely unavailable videos
    """
    # Videos with certain patterns are often removed
    suspicious_patterns = [
        youtube_id.startswith('---'),  # Often placeholder or removed
        len(youtube_id) < 8,           # Too short to be valid
        youtube_id.count('-') > 3,     # Unusual pattern
    ]
    return any(suspicious_patterns)


def download_with_cookies(youtube_id, start_time, output_file, args, timeout=45):
    """Download using manual cookie file with timeout"""
    try:
        if not os.path.exists("cookies.txt"):
            return False
        
        # Get audio URL with shorter timeout
        url_cmd = [
            "yt-dlp", 
            "--cookies", "cookies.txt",
            "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "--socket-timeout", "10",
            "-f", "bestaudio/best",
            "-g", 
            f"https://www.youtube.com/watch?v={youtube_id}"
        ]
        
        result = subprocess.run(url_cmd, capture_output=True, text=True, timeout=timeout)
        
        if result.returncode != 0:
            error_msg = result.stderr.lower()
            if any(x in error_msg for x in ['removed', 'unavailable', 'private', 'deleted']):
                print(f"Video unavailable: {youtube_id}")
                return False
            print(f"Error getting URL: {result.stderr[:100]}...")
            return False
        
        audio_url = result.stdout.strip()
        if not audio_url:
            return False
        
        # Download with ffmpeg
        sample_rate = getattr(args, 'sample_rate', DEFAULT_FS) or DEFAULT_FS
        ffmpeg_cmd = [
            "ffmpeg", "-y", "-loglevel", "quiet",
            "-ss", start_time, "-t", "10",
            "-i", audio_url, "-ar", str(sample_rate), "-ac", "1",
            "-f", "wav", output_file
        ]
        
        result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, timeout=timeout)
        
        if result.returncode == 0 and os.path.exists(output_file) and os.path.getsize(output_file) > 1000:
            return True
        
        return False
        
    except subprocess.TimeoutExpired:
        print(f"Download timed out: {youtube_id}")
        return False
    except Exception as e:
        print(f"Cookie download error: {e}")
        return False


def download_alternative_method(youtube_id, start_time, output_file, args):
    """
    Alternative download method with different yt-dlp parameters
    """
    try:
        import tempfile
        
        # Try different format selections
        format_options = [
            "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio",
            "worst[height<=480]/bestaudio/best",
            "bestaudio[filesize<50M]/bestaudio"
        ]
        
        for fmt in format_options:
            print(f"Trying format: {fmt}")
            
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_output = os.path.join(temp_dir, f"{youtube_id}")
                
                cmd = [
                    "yt-dlp",
                    "--no-check-certificate",
                    "--ignore-errors",
                    "--no-warnings",
                    "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "-f", fmt,
                ]
                
                # Add cookies if available
                if os.path.exists("cookies.txt"):
                    cmd.extend(["--cookies", "cookies.txt"])
                
                cmd.extend([
                    "--extract-audio",
                    "--audio-format", "wav",
                    "--postprocessor-args", f"ffmpeg:-ss {start_time} -t 10 -ar 16000 -ac 1",
                    "-o", f"{temp_output}.%(ext)s",
                    f"https://www.youtube.com/watch?v={youtube_id}"
                ])
                
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
                    
                    if result.returncode == 0:
                        # Look for the output file
                        output_files = [f for f in os.listdir(temp_dir) if f.startswith(youtube_id)]
                        
                        if output_files:
                            temp_audio = os.path.join(temp_dir, output_files[0])
                            
                            # Copy to final location
                            import shutil
                            shutil.copy2(temp_audio, output_file)
                            
                            if os.path.exists(output_file) and os.path.getsize(output_file) > 1000:
                                print(f"Success with format {fmt}")
                                return True
                    
                except subprocess.TimeoutExpired:
                    print(f"Timeout with format {fmt}")
                    continue
                except Exception as e:
                    print(f"Error with format {fmt}: {e}")
                    continue
        
        return False
        
    except Exception as e:
        print(f"Alternative method error: {e}")
        return False


def download_with_cookies(youtube_id, start_time, output_file, args):
    """Download using manual cookie file"""
    try:
        print("Trying download with cookie file...")
        
        # Check if cookies.txt exists
        cookie_file = "cookies.txt"
        if not os.path.exists(cookie_file):
            print("Warning: cookies.txt not found. Please export cookies from your browser.")
            return False
        
        # Get the best audio URL
        url_cmd = [
            "yt-dlp", 
            "--cookies", cookie_file,
            "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "-f", "bestaudio/best",
            "-g", 
            f"https://www.youtube.com/watch?v={youtube_id}"
        ]
        
        print(f"Running command: {' '.join(url_cmd)}")
        result = subprocess.run(url_cmd, capture_output=True, text=True, timeout=45)
        
        if result.returncode != 0:
            print(f"Error getting URL: {result.stderr}")
            return False
        
        audio_url = result.stdout.strip()
        if not audio_url:
            print("No audio URL returned")
            return False
        
        print(f"Got audio URL, now downloading with ffmpeg...")
        
        # Download with ffmpeg
        sample_rate = getattr(args, 'sample_rate', DEFAULT_FS) or DEFAULT_FS
        ffmpeg_cmd = [
            "ffmpeg",
            "-y",
            "-ss", start_time,
            "-t", "10",
            "-i", audio_url,
            "-ar", str(sample_rate),
            "-ac", "1",
            "-f", "wav",
            output_file
        ]
        
        result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, timeout=90)
        
        if result.returncode == 0:
            if os.path.exists(output_file) and os.path.getsize(output_file) > 0:
                print(f"Successfully created: {output_file}")
                return True
            else:
                print("ffmpeg completed but no valid file created")
                return False
        else:
            print(f"ffmpeg error: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("Download timed out")
        return False
    except Exception as e:
        print(f"Error in cookie download: {e}")
        return False


def download_basic(youtube_id, start_time, output_file, args, timeout=20):
    """Basic download without cookies - fast timeout"""
    try:
        url_cmd = [
            "yt-dlp", 
            "--socket-timeout", "5",
            "-f", "bestaudio/best",
            "-g", 
            f"https://www.youtube.com/watch?v={youtube_id}"
        ]
        
        result = subprocess.run(url_cmd, capture_output=True, text=True, timeout=timeout)
        
        if result.returncode != 0:
            return False
        
        audio_url = result.stdout.strip()
        if not audio_url:
            return False
        
        sample_rate = getattr(args, 'sample_rate', DEFAULT_FS) or DEFAULT_FS
        ffmpeg_cmd = [
            "ffmpeg", "-y", "-loglevel", "quiet",
            "-ss", start_time, "-t", "10",
            "-i", audio_url, "-ar", str(sample_rate), "-ac", "1",
            "-f", "wav", output_file
        ]
        
        result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0 and os.path.exists(output_file) and os.path.getsize(output_file) > 1000
        
    except subprocess.TimeoutExpired:
        return False
    except Exception:
        return False


def download_full_then_extract(youtube_id, start_time, output_file, args, timeout=60):
    """Download full video then extract segment - with timeout control"""
    try:
        import tempfile
        
        with tempfile.TemporaryDirectory() as temp_dir:
            cookie_file = "cookies.txt" if os.path.exists("cookies.txt") else None
            temp_output = os.path.join(temp_dir, f"{youtube_id}")
            
            download_cmd = [
                "yt-dlp",
                "--no-check-certificate",
                "--socket-timeout", "10",
                "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "-f", "bestaudio/best",
                "--extract-audio",
                "--audio-format", "wav",
                "--audio-quality", "0",
            ]
            
            if cookie_file:
                download_cmd.extend(["--cookies", cookie_file])
            
            download_cmd.extend([
                "-o", f"{temp_output}.%(ext)s",
                f"https://www.youtube.com/watch?v={youtube_id}"
            ])
            
            result = subprocess.run(download_cmd, capture_output=True, text=True, timeout=timeout)
            
            if result.returncode == 0:
                downloaded_files = [f for f in os.listdir(temp_dir) 
                                 if f.startswith(youtube_id) and f.endswith('.wav')]
                
                if downloaded_files:
                    full_audio_path = os.path.join(temp_dir, downloaded_files[0])
                    
                    sample_rate = getattr(args, 'sample_rate', DEFAULT_FS) or DEFAULT_FS
                    extract_cmd = [
                        "ffmpeg", "-y", "-loglevel", "quiet",
                        "-i", full_audio_path,
                        "-ss", start_time, "-t", "10",
                        "-ar", str(sample_rate), "-ac", "1",
                        output_file
                    ]
                    
                    extract_result = subprocess.run(extract_cmd, capture_output=True, text=True, timeout=30)
                    
                    return (extract_result.returncode == 0 and 
                           os.path.exists(output_file) and 
                           os.path.getsize(output_file) > 1000)
            
            return False
            
    except subprocess.TimeoutExpired:
        print(f"Full download timed out: {youtube_id}")
        return False
    except Exception as e:
        return False


def alternative_download(youtube_id, start_time, output_file, args):
    """
    Alternative download method - download full video then extract segment
    """
    try:
        import tempfile
        import os
        
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_audio = os.path.join(temp_dir, f"{youtube_id}_full.%(ext)s")
            
            # Download full audio
            download_cmd = [
                "yt-dlp",
                "--cookies-from-browser", "chrome",
                "--user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "-f", "bestaudio/best",
                "--extract-audio",
                "--audio-format", "wav",
                "-o", temp_audio,
                f"https://www.youtube.com/watch?v={youtube_id}"
            ]
            
            result = subprocess.run(download_cmd, capture_output=True, text=True, timeout=180)
            
            if result.returncode == 0:
                # Find the downloaded file
                downloaded_files = [f for f in os.listdir(temp_dir) if f.startswith(youtube_id)]
                if downloaded_files:
                    full_audio_path = os.path.join(temp_dir, downloaded_files[0])
                    
                    # Extract the 10-second segment
                    extract_cmd = [
                        "ffmpeg",
                        "-y",
                        "-i", full_audio_path,
                        "-ss", start_time,
                        "-t", "10",
                        "-ar", str(args.sample_rate if hasattr(args, 'sample_rate') and args.sample_rate else DEFAULT_FS),
                        "-ac", "1",
                        output_file
                    ]
                    
                    extract_result = subprocess.run(extract_cmd, capture_output=True, text=True, timeout=60)
                    
                    if extract_result.returncode == 0:
                        print(f"Alternative download successful: {youtube_id}")
                        return True
            
            print(f"Alternative download failed: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"Alternative download error: {e}")
        return False


def create_csv(class_name, args):
    """
    Function for creating csv file containing all clips and corresponding info for given class
    Blacklisted classes functionality implemented here
    :param class_name:
    :param args:
    :return:
    """
    # construct path to destination dir
    dst_dir = args.destination_dir if args.destination_dir is not None else DEFAULT_DEST_DIR
    csv_dataset = args.csv_dataset if args.csv_dataset is not None else DEFAULT_CSV_DATASET

    new_csv_path = os.path.join(str(dst_dir), class_name + '.csv')
    print(f"Creating CSV: {new_csv_path}")

    # Should check if CSV already exists and possibly return if so? Overwriting for now
    if os.path.isfile(new_csv_path):
        print("A CSV file for class " + class_name + ' already exists.')
        print("*** Overwriting " + str(new_csv_path) + " ***")

    label_id = get_label_id(class_name, args)  # Get a list of label IDs which match class_name

    if args.blacklist is not None:
        blacklisted_ids = [get_label_id(blacklisted_class, args) for blacklisted_class in args.blacklist] # Get a list of label IDs for blacklisted classes
        blacklisted_ids = [id for blacklist in blacklisted_ids for id in blacklist]  # Flatten list of lists into a single list
    else:
        blacklisted_ids = []

    with open(csv_dataset) as dataset, open(new_csv_path, 'w', newline='') as new_csv:
        reader = csv.reader(dataset, skipinitialspace=True)
        writer = csv.writer(new_csv)

        #  Include the row if it contains label for desired class and no labels of blacklisted classes
        to_write = [row for row in reader for label in label_id if label in row[3]
                    and bool(set(row[3].split(",")).intersection(blacklisted_ids)) is False]  # added check for blacklisted classes
        writer.writerows(to_write)

    print("Finished writing CSV file for " + class_name)

    return new_csv_path


def get_label_id(class_name, args):
    """
    Function for getting corresponding label for a class name

    The function looks for class name in the CSV file of label indices. It performs sub-string searching rather than
    matching so that class labels are more reliably found. Problematic naming convention of classes in AudioSet
    forces this to be the case. For example, inputting "female speech" as 'label' will not find class
    "Female speech, woman speaking" if exact string matching is performed. Also problems with exact string matching if
    there are spaces in class names.
    Sub-string matching will result in multiple class labels being found for certain input stings. e.g. "dog"

    28/06/18: implemented 'strict' option
    :param class_name: label to search for
    :param strict:
    :return: ID for given label. Given as a list as there can be multiple matching IDs found (e.g. "dog")
    """

    label_file_path = args.label_file if args.label_file is not None else DEFAULT_LABEL_FILE

    with open(label_file_path) as label_file:
        reader = csv.DictReader(label_file)
        index, id, display_name, = reader.fieldnames

        if hasattr(args, 'strict') and args.strict:
            label_ids = [row[id] for row in reader if (class_name.lower() == row[display_name].lower())]
        else:
            label_ids = [row[id] for row in reader if (class_name.lower() in row[display_name].lower())]

        if not label_ids:
            print("No id for class " + class_name)
        elif len(label_ids) > 1: # If there is more than one class containing the specified string
            print("Multiple labels found for " + class_name)
            print(label_ids)
        else:
            print("Label ID for \"" + class_name + "\": " + str(label_ids))

    return label_ids  # Return a list of matching label IDs


def get_yt_ids(label_ids, csv):
    """
    Function for getting the youtube IDs for all clips where the specified classes are present

    :param label_ids: list of label IDs (will most often only contain 1 label)
    :param csv: path to csv file containing dataset info (i.e. youtube ids and labels)
    :return: dictionary containing label-YouTubeID pairs
    """
    yt_ids = {label: [] for label in label_ids}  # Empty dictionary with class labels as keys and empty lists as values

    with open(csv) as dataset:
        reader = csv.reader(dataset, skipinitialspace=True)

        # Add youtube id to list for label if corresponding audio contains that label/class
        for row in reader:
            for label in label_ids:
                if label in row[3]:
                    yt_ids[label].append(row[0])

    # Remove empty entries and print stats
    labels_to_remove = []
    for label in yt_ids:
        if not yt_ids[label]:
            print("No clips found for " + label)
            labels_to_remove.append(label)
        else:
            print("Youtube ids for label " + label + ": " + str(len(yt_ids[label])) + " clips")

    for label in labels_to_remove:
        yt_ids.pop(label)

    return yt_ids  # return dict containing label-yt-id pairs


def find_files(yt_ids, file_dir, dst_dir=None):
    """
    Function for getting all wav files associated with given label/class

    Name of function was originally 'sort_wav_files' but 'wav' was removed to avoid confusion. Script can be used to
    sort archive files, or any other type of file, no distinction is made.

    :param yt_ids: dict containing label-yt_id pairs
    :param file_dir: directory where files are stored
    :param dst_dir:
    :return:
    """
    dst_dir = file_dir if dst_dir is None else dst_dir

    for class_name in yt_ids:  # keys in yt_ids are class names
        class_dst_dir = os.path.join(dst_dir, class_name)
        if not os.path.exists(class_dst_dir):
            os.makedirs(class_dst_dir)
            print("Created directory for class: " + class_name)
            print(class_dst_dir)

    for file in os.listdir(file_dir):  # Iterate through all files in dir
        for class_name, yt_id_list in yt_ids.items():  # Iterate through label-yt_id_list pairs
            if any(yt_id in file for yt_id in yt_id_list):  # if the file name in list of yt_ids
                src = os.path.join(file_dir, file)  # source file
                dst = os.path.join(dst_dir, class_name, file)  # destination of file
                copyfile(src, dst)  # copy file into directory for current label

    print("Finished sorting files")